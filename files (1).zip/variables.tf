# ==============================================================================
# Variables – terraform-kannika-armory
# ==============================================================================

# --------------------------------------------------------------------------
# Core
# --------------------------------------------------------------------------
variable "namespace" {
  description = "Kubernetes namespace in which Kannika Armory will be installed."
  type        = string
  default     = "kannika-armory"
}

variable "create_namespace" {
  description = "Whether to create the namespace. Set false if it already exists."
  type        = bool
  default     = true
}

variable "namespace_labels" {
  description = "Extra labels to add to the namespace."
  type        = map(string)
  default     = {}
}

variable "namespace_annotations" {
  description = "Extra annotations to add to the namespace."
  type        = map(string)
  default     = {}
}

variable "release_name" {
  description = "Helm release name."
  type        = string
  default     = "kannika-armory"
}

variable "chart_version" {
  description = "Kannika Armory Helm chart version to install. See https://docs.kannika.io/release-notes/"
  type        = string
  default     = "0.15.2"
}

# --------------------------------------------------------------------------
# License
# --------------------------------------------------------------------------
variable "license_key" {
  description = "Kannika Armory license key. Request a free trial at https://docs.kannika.io/trial-license/"
  type        = string
  sensitive   = true
}

# --------------------------------------------------------------------------
# Components
# --------------------------------------------------------------------------
variable "operator_enabled" {
  description = "Enable the Kannika Armory operator component."
  type        = bool
  default     = true
}

variable "operator_replicas" {
  description = "Number of operator replicas."
  type        = number
  default     = 1
}

variable "api_enabled" {
  description = "Enable the GraphQL / REST API component."
  type        = bool
  default     = true
}

variable "api_replicas" {
  description = "Number of API replicas."
  type        = number
  default     = 1
}

variable "console_enabled" {
  description = "Enable the web-based Console UI component."
  type        = bool
  default     = true
}

# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------
variable "storage_class_name" {
  description = "Kubernetes StorageClass used for API internal storage."
  type        = string
  default     = ""
}

variable "api_storage_size" {
  description = "PVC size for the API storage component."
  type        = string
  default     = "5Gi"
}

# --------------------------------------------------------------------------
# Images
# --------------------------------------------------------------------------
variable "image_registry" {
  description = "Global image registry override (useful for air-gapped clusters or internal mirrors)."
  type        = string
  default     = ""
}

variable "image_pull_secrets" {
  description = "List of image pull secret names."
  type        = list(string)
  default     = []
}

# --------------------------------------------------------------------------
# Operator watch scope
# --------------------------------------------------------------------------
variable "watched_namespaces" {
  description = "Namespaces the operator will watch for Backup/Restore CRs. Empty = all namespaces."
  type        = list(string)
  default     = []
}

# --------------------------------------------------------------------------
# Helm
# --------------------------------------------------------------------------
variable "atomic" {
  description = "If true, Helm will roll back on failure."
  type        = bool
  default     = true
}

variable "timeout_seconds" {
  description = "Helm operation timeout in seconds."
  type        = number
  default     = 600
}

variable "extra_helm_values" {
  description = "Map of extra Helm values to pass via --set."
  type        = map(string)
  default     = {}
}

variable "helm_values_files" {
  description = "List of raw YAML values strings (equivalent to -f values.yaml)."
  type        = list(string)
  default     = []
}
