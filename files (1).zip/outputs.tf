# ==============================================================================
# Outputs – terraform-kannika-armory
# ==============================================================================

output "namespace" {
  description = "Kubernetes namespace where Kannika Armory is installed."
  value       = local.namespace
}

output "release_name" {
  description = "Helm release name of the Kannika Armory platform."
  value       = helm_release.kannika_armory.name
}

output "chart_version" {
  description = "Installed chart version."
  value       = helm_release.kannika_armory.version
}

output "license_secret_name" {
  description = "Name of the Kubernetes Secret holding the license key."
  value       = kubernetes_secret.license.metadata[0].name
}

output "operator_enabled" {
  description = "Whether the operator component is enabled."
  value       = var.operator_enabled
}

output "api_enabled" {
  description = "Whether the API component is enabled."
  value       = var.api_enabled
}

output "console_enabled" {
  description = "Whether the Console UI is enabled."
  value       = var.console_enabled
}
