# ==============================================================================
# Kannika Armory – Terraform Module
# Installs Kannika Armory (Kubernetes-native Kafka backup & restore)
# via Helm CRDs + platform chart.
# Docs: https://docs.kannika.io/installation/
# ==============================================================================

locals {
  namespace         = var.namespace
  license_secret    = "${var.release_name}-license"
  helm_repo_url     = "https://charts.kannika.io"
  crd_chart         = "kannika-armory-crds"
  platform_chart    = "kannika-armory"
}

# --------------------------------------------------------------------------
# 1. Namespace
# --------------------------------------------------------------------------
resource "kubernetes_namespace" "kannika" {
  count = var.create_namespace ? 1 : 0

  metadata {
    name = local.namespace
    labels = merge(
      { "app.kubernetes.io/managed-by" = "terraform" },
      var.namespace_labels
    )
    annotations = var.namespace_annotations
  }
}

# --------------------------------------------------------------------------
# 2. License Key Secret
# --------------------------------------------------------------------------
resource "kubernetes_secret" "license" {
  metadata {
    name      = local.license_secret
    namespace = local.namespace
  }

  data = {
    "license.key" = var.license_key
  }

  type = "Opaque"

  depends_on = [kubernetes_namespace.kannika]
}

# --------------------------------------------------------------------------
# 3. CRD Helm Release (installed separately so upgrades are safe)
# --------------------------------------------------------------------------
resource "helm_release" "kannika_crds" {
  name             = "${var.release_name}-crds"
  repository       = local.helm_repo_url
  chart            = local.crd_chart
  version          = var.chart_version
  namespace        = local.namespace
  create_namespace = false
  atomic           = var.atomic
  timeout          = var.timeout_seconds

  depends_on = [kubernetes_namespace.kannika]
}

# --------------------------------------------------------------------------
# 4. Platform Helm Release
# --------------------------------------------------------------------------
resource "helm_release" "kannika_armory" {
  name             = var.release_name
  repository       = local.helm_repo_url
  chart            = local.platform_chart
  version          = var.chart_version
  namespace        = local.namespace
  create_namespace = false
  atomic           = var.atomic
  timeout          = var.timeout_seconds

  # --- License ---
  set {
    name  = "license.secretName"
    value = local.license_secret
  }

  # --- Operator ---
  set {
    name  = "operator.enabled"
    value = tostring(var.operator_enabled)
  }
  set {
    name  = "operator.replicaCount"
    value = tostring(var.operator_replicas)
  }

  # --- API / Console ---
  set {
    name  = "api.enabled"
    value = tostring(var.api_enabled)
  }
  set {
    name  = "api.replicaCount"
    value = tostring(var.api_replicas)
  }
  set {
    name  = "console.enabled"
    value = tostring(var.console_enabled)
  }

  # --- API Storage (internal DB) ---
  set {
    name  = "api.storage.storageClassName"
    value = var.storage_class_name
  }
  set {
    name  = "api.storage.size"
    value = var.api_storage_size
  }

  # --- Image registry override (for air-gapped / internal mirror) ---
  dynamic "set" {
    for_each = var.image_registry != "" ? [1] : []
    content {
      name  = "global.imageRegistry"
      value = var.image_registry
    }
  }

  # --- Image pull secrets ---
  dynamic "set" {
    for_each = var.image_pull_secrets
    content {
      name  = "global.imagePullSecrets[${set.key}]"
      value = set.value
    }
  }

  # --- Namespaces the operator watches ---
  dynamic "set" {
    for_each = length(var.watched_namespaces) > 0 ? [join(",", var.watched_namespaces)] : []
    content {
      name  = "operator.watchedNamespaces"
      value = set.value
    }
  }

  # --- Arbitrary values override (escape hatch) ---
  dynamic "set" {
    for_each = var.extra_helm_values
    content {
      name  = set.key
      value = set.value
    }
  }

  values = var.helm_values_files

  depends_on = [
    helm_release.kannika_crds,
    kubernetes_secret.license,
  ]
}
