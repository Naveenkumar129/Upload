# ==============================================================================
# Example: Basic – installs Kannika Armory + one Kafka EventHub + S3 backup
# ==============================================================================

provider "kubernetes" {
  config_path = "~/.kube/config"
}

provider "helm" {
  kubernetes {
    config_path = "~/.kube/config"
  }
}

# ---- 1. Install Kannika Armory platform ----
module "kannika_armory" {
  source  = "<YOUR_REGISTRY_HOSTNAME>/your-org/kannika-armory/kubernetes"
  version = "~> 1.0"

  namespace    = "kannika-armory"
  release_name = "kannika"
  chart_version = "0.15.2"
  license_key  = var.kannika_license_key

  operator_enabled = true
  api_enabled      = true
  console_enabled  = true
}

# ---- 2. EventHub – point to your Kafka cluster ----
module "kafka_eventhub" {
  source = "<YOUR_REGISTRY_HOSTNAME>/your-org/kannika-armory/kubernetes//modules/eventhub"

  name              = "my-kafka"
  namespace         = module.kannika_armory.namespace
  bootstrap_servers = "kafka-broker-0.kafka:9092,kafka-broker-1.kafka:9092"

  depends_on = [module.kannika_armory]
}

# ---- 3. S3 Storage ----
resource "kubernetes_secret" "aws_creds" {
  metadata {
    name      = "aws-s3-credentials"
    namespace = module.kannika_armory.namespace
  }
  data = {
    accessKeyId     = var.aws_access_key_id
    secretAccessKey = var.aws_secret_access_key
  }
}

module "s3_storage" {
  source = "<YOUR_REGISTRY_HOSTNAME>/your-org/kannika-armory/kubernetes//modules/storage"

  name      = "s3-backup-storage"
  namespace = module.kannika_armory.namespace
  type      = "s3"

  s3_bucket = "my-kafka-backups"
  s3_region = "us-east-1"
  s3_prefix = "kannika/"

  credential_secret_ref = { name = kubernetes_secret.aws_creds.metadata[0].name }

  depends_on = [module.kannika_armory]
}

# ---- 4. Backup – hourly, all topics ----
module "hourly_backup" {
  source = "<YOUR_REGISTRY_HOSTNAME>/your-org/kannika-armory/kubernetes//modules/backup"

  name          = "hourly-all-topics"
  namespace     = module.kannika_armory.namespace
  eventhub_ref  = module.kafka_eventhub.eventhub_name
  storage_ref   = module.s3_storage.storage_name
  schedule      = "0 * * * *"
  topics        = [{ pattern = ".*" }]

  retention = {
    maxBackups = 168  # 7 days of hourly backups
    maxAge     = "7d"
  }

  compression = {
    algorithm = "zstd"
    level     = 3
  }

  depends_on = [module.kafka_eventhub, module.s3_storage]
}

# ---- Variables ----
variable "kannika_license_key" {
  description = "Kannika Armory license key."
  type        = string
  sensitive   = true
}

variable "aws_access_key_id" {
  type      = string
  sensitive = true
}

variable "aws_secret_access_key" {
  type      = string
  sensitive = true
}

# ---- Outputs ----
output "kannika_namespace" {
  value = module.kannika_armory.namespace
}

output "backup_name" {
  value = module.hourly_backup.backup_name
}
