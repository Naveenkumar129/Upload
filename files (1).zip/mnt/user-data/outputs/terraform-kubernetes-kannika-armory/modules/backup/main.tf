# ==============================================================================
# Sub-module: backup
# Creates a Backup Custom Resource for Kannika Armory.
# Docs: https://docs.kannika.io/user-guide/backup/
# ==============================================================================

resource "kubernetes_manifest" "backup" {
  manifest = {
    apiVersion = "armory.kannika.io/v1alpha1"
    kind       = "Backup"
    metadata = {
      name      = var.name
      namespace = var.namespace
      labels    = var.labels
    }
    spec = {
      eventHubRef = {
        name = var.eventhub_ref
      }

      storageRef = {
        name = var.storage_ref
      }

      # Topics to back up
      topics = var.topics

      # Scheduling
      schedule = var.schedule

      # Data retention
      retention = var.retention != null ? var.retention : null

      # Compression
      compression = var.compression != null ? var.compression : null

      # Worker configuration
      workerGroups = length(var.worker_groups) > 0 ? var.worker_groups : null

      # Segments
      segments = var.segments != null ? var.segments : null

      # Additional properties
      additionalProperties = length(var.additional_properties) > 0 ? var.additional_properties : null
    }
  }
}
