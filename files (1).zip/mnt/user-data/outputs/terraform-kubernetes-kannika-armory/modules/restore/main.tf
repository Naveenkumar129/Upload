# ==============================================================================
# Sub-module: restore
# Creates a Restore Custom Resource for Kannika Armory.
# Docs: https://docs.kannika.io/user-guide/restore/
# ==============================================================================

resource "kubernetes_manifest" "restore" {
  manifest = {
    apiVersion = "armory.kannika.io/v1alpha1"
    kind       = "Restore"
    metadata = {
      name      = var.name
      namespace = var.namespace
      labels    = var.labels
    }
    spec = {
      backupRef = {
        name = var.backup_ref
      }

      targetEventHubRef = {
        name = var.target_eventhub_ref
      }

      # Topics to restore (defaults to all)
      topics = length(var.topics) > 0 ? var.topics : null

      # Point-in-time
      pointInTime = var.point_in_time != null ? var.point_in_time : null

      # Schema mapping overrides
      schemaMapping = length(var.schema_mapping) > 0 ? var.schema_mapping : null

      # Topic renames
      topicMapping = length(var.topic_mapping) > 0 ? var.topic_mapping : null
    }
  }
}
