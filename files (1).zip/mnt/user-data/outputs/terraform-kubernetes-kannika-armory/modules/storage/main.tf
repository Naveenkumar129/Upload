# ==============================================================================
# Sub-module: storage
# Creates a Storage Custom Resource for Kannika Armory.
# Supported types: s3 | gcs | azureblob | volume
# Docs: https://docs.kannika.io/user-guide/storage/
# ==============================================================================

locals {
  s3_spec = var.type == "s3" ? {
    s3 = {
      bucket            = var.s3_bucket
      region            = var.s3_region
      prefix            = var.s3_prefix
      endpointUrl       = var.s3_endpoint_url
      credentialSecretRef = var.credential_secret_ref
    }
  } : {}

  gcs_spec = var.type == "gcs" ? {
    gcs = {
      bucket            = var.gcs_bucket
      prefix            = var.gcs_prefix
      credentialSecretRef = var.credential_secret_ref
    }
  } : {}

  azure_spec = var.type == "azureblob" ? {
    azureBlob = {
      containerName       = var.azure_container_name
      storageAccountName  = var.azure_storage_account
      prefix              = var.azure_prefix
      credentialSecretRef = var.credential_secret_ref
    }
  } : {}

  volume_spec = var.type == "volume" ? {
    volume = {
      storageClassName = var.volume_storage_class
      size             = var.volume_size
    }
  } : {}

  merged_spec = merge(local.s3_spec, local.gcs_spec, local.azure_spec, local.volume_spec)
}

resource "kubernetes_manifest" "storage" {
  manifest = {
    apiVersion = "armory.kannika.io/v1alpha1"
    kind       = "Storage"
    metadata = {
      name      = var.name
      namespace = var.namespace
    }
    spec = local.merged_spec
  }
}
