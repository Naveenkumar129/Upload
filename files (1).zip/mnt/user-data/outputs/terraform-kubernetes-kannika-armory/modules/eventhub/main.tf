# ==============================================================================
# Sub-module: eventhub
# Creates a KafkaEventHub Custom Resource in the cluster so Kannika Armory
# knows where your Kafka cluster lives.
# Docs: https://docs.kannika.io/user-guide/eventhub/kafka/
# ==============================================================================

resource "kubernetes_manifest" "kafka_eventhub" {
  manifest = {
    apiVersion = "armory.kannika.io/v1alpha1"
    kind       = "KafkaEventHub"
    metadata = {
      name      = var.name
      namespace = var.namespace
    }
    spec = {
      bootstrapServers = var.bootstrap_servers

      # Optional: authentication
      authentication = var.authentication != null ? var.authentication : null

      # Optional: schema registry reference
      schemaRegistry = var.schema_registry != null ? var.schema_registry : null
    }
  }
}
