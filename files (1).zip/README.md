# terraform-kannika-armory

Terraform module to deploy **Kannika Armory** — the Kubernetes-native Kafka backup & restore platform — and manage its Custom Resources (EventHub, Storage, Backup, Restore).

> **Reference:** [docs.kannika.io](https://docs.kannika.io) · Kannika Armory v0.15.x

---

## What this module does

| Layer | What is created |
|---|---|
| **Platform** (root module) | Kubernetes namespace, license Secret, CRD Helm release, Kannika Armory Helm release |
| **`modules/eventhub`** | `KafkaEventHub` Custom Resource |
| **`modules/storage`** | `Storage` Custom Resource (S3 / GCS / Azure Blob / Volume) |
| **`modules/backup`** | `Backup` Custom Resource with schedule, retention, compression |
| **`modules/restore`** | `Restore` Custom Resource with point-in-time & topic-mapping support |

---

## Requirements

| Tool | Version |
|---|---|
| Terraform | >= 1.5.0 |
| Kubernetes provider | >= 2.23.0 |
| Helm provider | >= 2.12.0 |
| Kubernetes | >= 1.30 |
| Helm CLI | >= 3.9 |
| Kannika Armory license | [Request free trial](https://docs.kannika.io/trial-license/) |

---

## Quick start

```hcl
module "kannika_armory" {
  source  = "<YOUR_REGISTRY>/your-org/kannika-armory/kubernetes"
  version = "~> 1.0"

  namespace     = "kannika-armory"
  chart_version = "0.15.2"
  license_key   = var.kannika_license_key
}

module "kafka_eventhub" {
  source    = "<YOUR_REGISTRY>/your-org/kannika-armory/kubernetes//modules/eventhub"
  name      = "my-kafka"
  namespace = module.kannika_armory.namespace
  bootstrap_servers = "broker-0.kafka:9092,broker-1.kafka:9092"
  depends_on = [module.kannika_armory]
}

module "s3_storage" {
  source    = "<YOUR_REGISTRY>/your-org/kannika-armory/kubernetes//modules/storage"
  name      = "s3-storage"
  namespace = module.kannika_armory.namespace
  type      = "s3"
  s3_bucket = "my-kafka-backups"
  s3_region = "us-east-1"
  credential_secret_ref = { name = "aws-creds-secret" }
  depends_on = [module.kannika_armory]
}

module "hourly_backup" {
  source       = "<YOUR_REGISTRY>/your-org/kannika-armory/kubernetes//modules/backup"
  name         = "hourly-backup"
  namespace    = module.kannika_armory.namespace
  eventhub_ref = module.kafka_eventhub.eventhub_name
  storage_ref  = module.s3_storage.storage_name
  schedule     = "0 * * * *"
  retention    = { maxBackups = 168, maxAge = "7d" }
  depends_on   = [module.kafka_eventhub, module.s3_storage]
}
```

---

## Root module inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `namespace` | string | `"kannika-armory"` | Kubernetes namespace |
| `create_namespace` | bool | `true` | Create the namespace |
| `release_name` | string | `"kannika-armory"` | Helm release name |
| `chart_version` | string | `"0.15.2"` | Kannika Armory chart version |
| `license_key` | string | **required** | License key (sensitive) |
| `operator_enabled` | bool | `true` | Enable operator component |
| `operator_replicas` | number | `1` | Operator replica count |
| `api_enabled` | bool | `true` | Enable API/GraphQL component |
| `api_replicas` | number | `1` | API replica count |
| `console_enabled` | bool | `true` | Enable Console UI |
| `storage_class_name` | string | `""` | StorageClass for API storage |
| `api_storage_size` | string | `"5Gi"` | PVC size for API storage |
| `image_registry` | string | `""` | Override global image registry |
| `image_pull_secrets` | list(string) | `[]` | Image pull secret names |
| `watched_namespaces` | list(string) | `[]` | Namespaces operator watches |
| `atomic` | bool | `true` | Helm atomic install |
| `timeout_seconds` | number | `600` | Helm timeout |
| `extra_helm_values` | map(string) | `{}` | Extra Helm `--set` values |
| `helm_values_files` | list(string) | `[]` | Raw YAML values overrides |

## Root module outputs

| Output | Description |
|---|---|
| `namespace` | Installed namespace |
| `release_name` | Helm release name |
| `chart_version` | Installed chart version |
| `license_secret_name` | Name of the license Secret |
| `operator_enabled` | Operator component state |
| `api_enabled` | API component state |
| `console_enabled` | Console component state |

---

## Sub-modules

### `modules/eventhub`

Creates a `KafkaEventHub` CR. Supports SASL, mTLS, HTTP Basic authentication and Confluent Schema Registry.

```hcl
module "eventhub" {
  source            = ".//modules/eventhub"
  name              = "prod-kafka"
  namespace         = "kannika-armory"
  bootstrap_servers = "broker:9092"

  # Optional SASL authentication
  authentication = {
    type                = "sasl"
    credentialSecretRef = { name = "sasl-secret" }
  }
}
```

### `modules/storage`

Creates a `Storage` CR. Supports `s3`, `gcs`, `azureblob`, `volume`.

```hcl
module "gcs_storage" {
  source     = ".//modules/storage"
  name       = "gcs-storage"
  namespace  = "kannika-armory"
  type       = "gcs"
  gcs_bucket = "my-bucket"
  credential_secret_ref = { name = "gcp-sa-secret" }
}
```

### `modules/backup`

Creates a `Backup` CR with cron schedule, topic selectors, retention and compression.

```hcl
module "backup" {
  source       = ".//modules/backup"
  name         = "daily-orders"
  namespace    = "kannika-armory"
  eventhub_ref = "prod-kafka"
  storage_ref  = "s3-storage"
  schedule     = "0 2 * * *"
  topics       = [{ pattern = "orders\\..*" }]
  retention    = { maxBackups = 30, maxAge = "30d" }
}
```

### `modules/restore`

Creates a `Restore` CR with optional point-in-time and topic mapping.

```hcl
module "restore" {
  source              = ".//modules/restore"
  name                = "restore-orders-staging"
  namespace           = "kannika-armory"
  backup_ref          = "daily-orders"
  target_eventhub_ref = "staging-kafka"
  point_in_time       = { timestamp = "2024-06-01T12:00:00Z" }
  topic_mapping       = [{ source = "orders-prod", target = "orders-staging" }]
}
```

---

## Publishing to an Internal Registry

### Option A — HCP Terraform / Terraform Enterprise Private Registry

The module must live in a Git repository named with the pattern `terraform-<PROVIDER>-<NAME>` and be tagged with semantic versions.

**1. Prepare the repository**

```bash
# Repository name must follow this exact pattern:
# terraform-kubernetes-kannika-armory
git init terraform-kubernetes-kannika-armory
cd terraform-kubernetes-kannika-armory
cp -r /path/to/this/module/. .
git add .
git commit -m "feat: initial Kannika Armory module"
```

**2. Tag a release**

```bash
git tag v1.0.0
git push origin main --tags
```

**3. Publish via HCP Terraform UI**

1. Go to **Registry → Publish → Module** in your HCP Terraform organisation.
2. Connect the repository (`terraform-kubernetes-kannika-armory`).
3. HCP Terraform auto-detects the version from the Git tag.

**4. Consume from the private registry**

```hcl
module "kannika_armory" {
  source  = "app.terraform.io/<YOUR_ORG>/kannika-armory/kubernetes"
  version = "~> 1.0"
  ...
}
```

**5. Authenticate in CI/CD**

```bash
export TF_TOKEN_app_terraform_io="<YOUR_TEAM_TOKEN>"
terraform init
```

---

### Option B — Terraform Enterprise (self-hosted) via API

```bash
BASE_URL="https://<YOUR_TFE_HOST>/api/v2"
TOKEN="<YOUR_TFE_TOKEN>"
ORG="your-org"

# Create module
curl -s -X POST "$BASE_URL/organizations/$ORG/registry-modules/vcs" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/vnd.api+json" \
  -d '{
    "data": {
      "attributes": {
        "vcs-repo": {
          "identifier":       "your-org/terraform-kubernetes-kannika-armory",
          "oauth-token-id":   "<VCS_OAUTH_TOKEN_ID>",
          "display-identifier": "terraform-kubernetes-kannika-armory"
        }
      },
      "type": "registry-modules"
    }
  }'
```

---

### Option C — Generic private registry (OpenTofu / Atmos)

If you run a registry compatible with the [Terraform Module Registry Protocol](https://developer.hashicorp.com/terraform/internals/module-registry-protocol):

```bash
# Package the module
tar -czf kannika-armory-1.0.0.tar.gz \
  main.tf variables.tf outputs.tf versions.tf modules/ examples/

# Upload via your registry's API (varies by implementation)
curl -X POST "https://registry.internal.example.com/v1/modules" \
  -H "Authorization: Bearer $REGISTRY_TOKEN" \
  -F "module=@kannika-armory-1.0.0.tar.gz" \
  -F "namespace=your-org" \
  -F "name=kannika-armory" \
  -F "provider=kubernetes" \
  -F "version=1.0.0"
```

Then reference it:

```hcl
terraform {
  required_providers {}
}

# In .terraformrc or TF_CLI_CONFIG_FILE:
# credentials "registry.internal.example.com" {
#   token = "<TOKEN>"
# }

module "kannika_armory" {
  source  = "registry.internal.example.com/your-org/kannika-armory/kubernetes"
  version = "~> 1.0"
  ...
}
```

---

## Directory structure

```
terraform-kubernetes-kannika-armory/
├── main.tf                    # Platform install (namespace, secret, Helm)
├── variables.tf
├── outputs.tf
├── versions.tf
├── modules/
│   ├── eventhub/              # KafkaEventHub CR
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   ├── storage/               # Storage CR (S3/GCS/Azure/Volume)
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   ├── backup/                # Backup CR
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   └── restore/               # Restore CR
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
└── examples/
    └── basic/                 # End-to-end example
        └── main.tf
```

---

## License

MIT — see [LICENSE](LICENSE).
